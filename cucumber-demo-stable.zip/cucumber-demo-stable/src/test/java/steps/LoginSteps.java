package steps;

import io.cucumber.java.en.*;

public class LoginSteps {
    @Given("the user is on the login page")
    public void the_user_is_on_the_login_page() {
        System.out.println("User is on login page");
    }

    @When("the user enters valid credentials")
    public void the_user_enters_valid_credentials() {
        System.out.println("User enters valid credentials");
    }

    @Then("the user should see the dashboard")
    public void the_user_should_see_the_dashboard() {
        System.out.println("User sees the dashboard");
    }
}
