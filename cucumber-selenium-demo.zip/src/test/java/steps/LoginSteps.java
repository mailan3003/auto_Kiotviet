package steps;

import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;

public class LoginSteps {
    WebDriver driver;

    @Given("the user opens the login page")
    public void open_login_page() {
        System.setProperty("webdriver.chrome.driver", "C:\\webdriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://the-internet.herokuapp.com/login");
    }

    @When("the user enters {string} and {string}")
    public void enter_credentials(String username, String password) {
        driver.findElement(By.id("username")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
    }

    @Then("the user should see the dashboard")
    public void check_dashboard() {
        Assert.assertTrue(driver.getCurrentUrl().contains("/secure"));
        driver.quit();
    }

    @Then("the user should see an error message")
    public void check_error() {
        WebElement flash = driver.findElement(By.id("flash"));
        Assert.assertTrue(flash.isDisplayed());
        driver.quit();
    }
}
